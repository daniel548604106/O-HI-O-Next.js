import React from "react";

const Cooperation = () => {
  return (
    <div>
      <h2>設計館的經營故事</h2>
      <p>
        在 O.HI.O
        擁有一家設計館是什麼體驗？聽我們自己說或許還不夠，就來聽聽這些設計師的分享吧！看看他們是如何決定加入
        O.HI.O，在 O.HI.O 遇到了怎樣特別的經歷，又取得了什麼樣的發展。
      </p>
    </div>
  );
};

export default Cooperation;
