## ESLINT with Prettier (Airbnb Style)

(https://gist.github.com/bradtraversy/aab26d1e8983d9f8d79be1a9ca894ab4)

## TailwindCSS Config

(https://tailwindcss.com/docs/guides/nextjs)

<<<<<<< HEAD
## Swiper

(https://swiperjs.com/react)
=======


>>>>>>> master

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!

## Deploy on Netlify


-[Package.json]

"build: "next build"
"export":"next export"

-[Netlify]

npm run build && npm run export 
