
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'daniel548604106',
  applicationName: 'o-hi-o',
  appUid: '2sty33LpB9Wg1sXXyD',
  orgUid: 'ea261697-7fe7-41db-959b-d65893b15176',
  deploymentUid: '2738bed3-5afa-4a4b-9c25-e94a6483e0ae',
  serviceName: 'o-hi-o',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'o-hi-o-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}