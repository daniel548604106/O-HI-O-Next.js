import React from "react";

const Type = () => {
  return <div>sdfsdf</div>;
};

export default Type;
