import React from 'react'

const index = () => {
  return (
    <div>
      my
    </div>
  )
}

export default index
