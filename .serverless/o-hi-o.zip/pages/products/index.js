import React from "react";

const index = () => {
  return <div>products</div>;
};

export default index;
