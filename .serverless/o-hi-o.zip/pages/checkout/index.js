import React from 'react'

const index = () => {
  return (
    <div>
      checkout
    </div>
  )
}

export default index
