import React from 'react'

const index = () => {
  return (
    <div>
      oauth
    </div>
  )
}

export default index
