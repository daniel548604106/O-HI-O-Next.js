import React from "react";

const index = () => {
  return <div>shops</div>;
};

export default index;
