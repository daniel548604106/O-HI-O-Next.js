import React from "react";

const index = () => {
  return <div>browse</div>;
};

export default index;
