import React from "react";

const index = () => {
  return <div>events</div>;
};

export default index;
