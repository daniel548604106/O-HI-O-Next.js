import React from "react";

const Event = () => {
  return <div>Event</div>;
};

export default Event;
